<?php 

include("../action/connection.php");
session_start();
include("../partials/header.php");

$name = $_POST['search'] ;

$sql     = " select * from user_emergency_post where type like '%$name%' OR heading like '%$name%' OR dept like '%$name%' OR location like '%$name%' and verification=1 ORDER BY date_time DESC"; 
$result  = mysqli_query($conn, $sql);
$num     = mysqli_num_rows($result);

if($num>0){
	
	for ($i=0; $i<$num ; $i++) { 

		$row = mysqli_fetch_array($result);

		echo '

		<div class="col-md-3">
			<a href="postProfile.php?id='.$row["P_id"].'&&type='.$row["type"].'"><span class="thumbnail" href="#"><img alt="" src="../'.$row['postimage'].'" style="height:200px; width:3    00px;"></span></a>
			<h2>'.$row['heading'].'</h2>
			<strong>'.$row['date_time'].'</strong>


		</div>   

		';


	}
}
else {
	# code...
	echo "<h1>No Result Found</h1>";
}
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</body>
</html> 