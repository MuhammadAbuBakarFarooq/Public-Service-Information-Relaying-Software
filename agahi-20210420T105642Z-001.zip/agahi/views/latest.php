<?php 
include("../action/connection.php");
session_start();
include("../partials/header.php");


?>




<ol class="breadcrumb">
  <li id="bred"><a href="../index.php">Home</a></li>
  <li><a href="publicSafety.php">Latest News</a></li>
</ol>
<div class="data">
    <?php 

    $sql     = " select users.userName,user_emergency_post.dept, user_emergency_post.heading,user_emergency_post.location,user_emergency_post.type, users.image, user_emergency_post.P_id, user_emergency_post.description, user_emergency_post.postimage, user_emergency_post.date_time from users join user_emergency_post on(users.CNIC=user_emergency_post.CNIC) where user_emergency_post.verification=1 ORDER BY date_time DESC"; 
    $result  = mysqli_query($conn, $sql);
    $num     = mysqli_num_rows($result);

    if($result){

     for ($i=0; $i<$num ; $i++) { 

       $row = mysqli_fetch_array($result);

       echo '

       <div class="col-md-3">
        <a href="postProfile.php?id='.$row["P_id"].'&&type='.$row["type"].'"><span class="thumbnail" href="#"><img alt="" src="../'.$row['postimage'].'" style="height:200px; width:3    00px;"></span></a>
        <h2>'.$row['heading'].'</h2>
        <p>added by <strong>'.$row['userName'].'</strong> directed to <strong>'.$row['dept'].'</strong></p>
        <strong>'.$row['date_time'].'</strong>
        
        
    </div>   

    ';


}}?>

</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</body>
</html> 