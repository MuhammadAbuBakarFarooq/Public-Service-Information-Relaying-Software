<?php 
include("../action/connection.php");
session_start();

include("../partials/header.php");


?>



<div class="container">
    <div class="jumbotron">
        <div class="row">
            <div class="col-md-12 col-md-offset-1">
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="thumbnail">

                        <?php 
                        $new=$_SESSION['userName'];


                        $query = "select * from users where users.userName like '$new'";

                        $result = mysqli_query($conn, $query);
                        $row = mysqli_fetch_array($result);

                        if ($result) {
                              # code...
                            echo '
                            <img src="../'.$row["image"].'" alt="">
                        </div>
                    </div>
                    <div class="col-md-8">
                        <h2 class="text">
                            <strong>User Name: </strong>'.$row["userName"].'
                        </h2>
                        <h2 ">
                            <strong>Email: </strong>'.$row["email"].'
                        </h2>
                        <h2>
                            <strong>Cell No: </strong>'.$row["Ph_No"].'
                        </h2><h2>
                        <strong>CNIC: </strong>'.$row["CNIC"].'
                    </h2>';
                }
                ?>

            </div>
            
</div>

            <div class="row">
                <div class="col-md-12">
                    <h2>
                        <a href="#">News Alerts</a>

                    </h2>
                    <?php 
                    $new=$_SESSION['userName'];


                    $query = "select * from users where users.userName like '$new'";

                    $result = mysqli_query($conn, $query);
                    $rowCheck = mysqli_fetch_array($result);
                    if ($result) {
                 # code...

                        $CNIC = $rowCheck["CNIC"];

                    }
                    $sql     = " select users.userName,user_emergency_post.dept, user_emergency_post.heading,user_emergency_post.location,user_emergency_post.type, users.image, user_emergency_post.P_id, user_emergency_post.description, user_emergency_post.postimage, user_emergency_post.date_time from users join user_emergency_post on(users.CNIC=user_emergency_post.CNIC) where user_emergency_post.type like 'News Alert' and user_emergency_post.verification=1 and users.CNIC=$CNIC ORDER BY date_time DESC"; 
                    $result  = mysqli_query($conn, $sql);
                    $num     = mysqli_num_rows($result);

                    if($num>0){

                       for ($i=0; $i<$num ; $i++) { 

                        echo '<div class="row">';

                        $row = mysqli_fetch_array($result);

                        echo '

                        <div class="col-md-3">
                            <a href="postProfile.php?id='.$row["P_id"].'&&type='.$row["type"].'"><span class="thumbnail" href="#"><img alt="" src="../'.$row['postimage'].'" style="height:200px; width:3    00px;"></span></a>
                            <h2>'.$row['heading'].'</h2>

                            <strong>'.$row['date_time'].'</strong>

                        </div>

                        ';


                    }
                    echo '</div>';
                }
                else{
                    echo "<h2>List Empty</h2>";
                }

                ?>
                <h2>
                    <a href="#">Events</a>

                </h2>
                <?php 
                $new=$_SESSION['userName'];


                $query = "select * from users where users.userName like '$new'";

                $result = mysqli_query($conn, $query);
                $rowCheck = mysqli_fetch_array($result);
                if ($result) {
                 # code...

                    $CNIC = $rowCheck["CNIC"];

                }
                $sql     = " select users.userName,user_emergency_post.dept, user_emergency_post.heading,user_emergency_post.location,user_emergency_post.type, users.image, user_emergency_post.P_id, user_emergency_post.description, user_emergency_post.postimage, user_emergency_post.date_time from users join user_emergency_post on(users.CNIC=user_emergency_post.CNIC) where user_emergency_post.type like 'Event' and user_emergency_post.verification=1 and users.CNIC=$CNIC ORDER BY date_time DESC"; 
                $result  = mysqli_query($conn, $sql);
                $num     = mysqli_num_rows($result);

                if($num>0){

                   for ($i=0; $i<$num ; $i++) { 

                    echo '<div class="row">';

                    $row = mysqli_fetch_array($result);

                    echo '

                    <div class="col-md-3">
                        <a href="postProfile.php?id='.$row["P_id"].'&&type='.$row["type"].'"><span class="thumbnail" href="#"><img alt="" src="../'.$row['postimage'].'" style="height:200px; width:300px;"></span></a>
                        <h2>'.$row['heading'].'</h2>

                        <strong>'.$row['date_time'].'</strong>

                    </div>

                    ';


                }
                echo '</div>';
            }
             else{
                    echo "<h2>List Empty</h2>";
                }

            ?>
            <h2>
                <a href="#">Losts</a>

            </h2>
            <?php 
            $new=$_SESSION['userName'];


            $query = "select * from users where users.userName like '$new'";

            $result = mysqli_query($conn, $query);
            $rowCheck = mysqli_fetch_array($result);
            if ($result) {
                 # code...

                $CNIC = $rowCheck["CNIC"];

            }
            $sql     = " select users.userName,user_emergency_post.dept, user_emergency_post.heading,user_emergency_post.location,user_emergency_post.type, users.image, user_emergency_post.P_id, user_emergency_post.description, user_emergency_post.postimage, user_emergency_post.date_time from users join user_emergency_post on(users.CNIC=user_emergency_post.CNIC) where user_emergency_post.type like 'Lost' and user_emergency_post.verification=1 and users.CNIC=$CNIC ORDER BY date_time DESC"; 
            $result  = mysqli_query($conn, $sql);
            $num     = mysqli_num_rows($result);

            if($num>0){

               for ($i=0; $i<$num ; $i++) { 

                echo '<div class="row">';

                $row = mysqli_fetch_array($result);

                echo '

                <div class="col-md-3">
                    <a href="postProfile.php?id='.$row["P_id"].'&&type='.$row["type"].'"><span class="thumbnail" href="#"><img alt="" src="../'.$row['postimage'].'" style="height:200px; width:300px;"></span></a>
                    <h2>'.$row['heading'].'</h2>

                    <strong>'.$row['date_time'].'</strong>

                </div>

                ';


            }
            echo '</div>';
        }
         else{
                    echo "<h2>List Empty</h2>";
                }

        ?>

        <h2>
            <a href="#">Founds</a>

        </h2>
        <?php 
        $new=$_SESSION['userName'];


        $query = "select * from users where users.userName like '$new'";

        $result = mysqli_query($conn, $query);
        $rowCheck = mysqli_fetch_array($result);
        if ($result) {
                 # code...

            $CNIC = $rowCheck["CNIC"];

        }
        $sql     = " select users.userName,user_emergency_post.dept, user_emergency_post.heading,user_emergency_post.location,user_emergency_post.type, users.image, user_emergency_post.P_id, user_emergency_post.description, user_emergency_post.postimage, user_emergency_post.date_time from users join user_emergency_post on(users.CNIC=user_emergency_post.CNIC) where user_emergency_post.type like 'Found' and user_emergency_post.verification=1 and users.CNIC=$CNIC ORDER BY date_time DESC"; 
        $result  = mysqli_query($conn, $sql);
        $num     = mysqli_num_rows($result);

        if($num>0){

           for ($i=0; $i<$num ; $i++) { 

            echo '<div class="row">';

            $row = mysqli_fetch_array($result);

            echo '

            <div class="col-md-3">
                <a href="postProfile.php?id='.$row["P_id"].'&&type='.$row["type"].'"><span class="thumbnail" href="#"><img alt="" src="../'.$row['postimage'].'" style="height:200px; width:300px;"></span></a>
                <h2>'.$row['heading'].'</h2>

                <strong>'.$row['date_time'].'</strong>

            </div>

            ';


        }
        echo '</div>';
    }
     else{
                    echo "<h2>List Empty</h2>";
                }

    ?>
</div>
</div>
</div>
</div>
</div>
</div>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</body>
</html> 