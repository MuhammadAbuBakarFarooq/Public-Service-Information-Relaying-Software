<?php 
include("../action/connection.php");
session_start();
include("../partials/header.php");


?>



<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="well well-sm">
                <form class="form-horizontal" action="../action/info.php" method="POST">
                    <fieldset>
                        <legend class="text-left">Add Post</legend>

                        <!-- heading-->
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="heading">Heading</label>
                            <div class="col-md-9">
                                <input type="text" class="form-control" id="heading" name="heading" placeholder="Enter the title" required>
                            </div>
                        </div>
                        <!-- code -->
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="id">Penal Code Id</label>
                            <div class="col-md-9">
                                <input type="number" class="form-control" id="id" name="Id" placeholder="Enter Penal Code Id" required>
                            </div>
                        </div>
                        <!-- code -->
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="sub_no">Sub Number</label>
                            <div class="col-md-9">
                                <input type="number" class="form-control" id="sub_no" name="sub_no" placeholder="Enter Sub Number" required>
                            </div>
                        </div>


                        <!-- Message body -->
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="exp">Explanation</label>
                            <div class="col-md-9">
                               <textarea class="form-control" id="exp" type="text" name="explanation" placeholder="Please enter your message here..." rows="5" required></textarea>
                           </div>
                       </div>
                       <!-- Message body -->
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="message">More Explanation</label>
                            <div class="col-md-9">
                               <textarea class="form-control" id="message" type="text" name="moreExplanation" placeholder="Please enter your message here..." rows="5"></textarea>
                           </div>
                       </div>
                       
                       <!-- Submission -->
                       <div class="form-group">
                        <div class="col-md-12 text-right">
                            <button type="submit" class="btn btn-primary btn-lg">Submit</button>
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>
</div>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</body>
</html>