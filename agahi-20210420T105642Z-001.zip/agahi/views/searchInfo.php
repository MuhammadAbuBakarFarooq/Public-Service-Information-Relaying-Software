<?php 
include("../action/connection.php");
session_start();

include("../partials/infoHeader.php");


?>




<div class="container">   
  <div class="col-md-12 product-info">
    <ul id="myTab" class="nav nav-tabs">

      <li class="active"><a href="#service-one" data-toggle="tab">Pakistan Penal Code</a></li>
      
    </ul>
    <div id="myTabContent" class="tab-content">
      <div class="tab-pane fade in active" id="service-one">

        <section class="container product-info" style="padding-top: 2%; background-color: white;">
         Links: <a href="/pakistan/constitution/">Constitution of Pakistan</a> | <a href="/pakistan/legislation/">Legislation</a> | <a href="/">www.pakistani.org</a><br><hr>
         <H2 align="center">Pakistan Penal Code (Act XLV of 1860)</H2>
         <H3 align="center">Act XLV of 1860</H3>
         <H4 align="center">October 6th, 1860</H4>
         <DIV ALIGN="CENTER">Amended by:
         Criminal Law (Amendment) Act, 2012 (XXIII of 2002),Criminal Law (Third Amendment) Act, 2011 (XXVI of 2011),Criminal Law (Second Amendment) Act, 2011 (XXV of 2011),Criminal Law (Amendment) Act, 2011 (XX of 2011),Criminal Law (Amendment) Act, 2010 (I of 2010),Protection of Women (Criminal Laws Amendment) Act, 2006,Criminal Laws (Amendment) Act, 2004 (I of 2005),Criminal Law (Amendment) Ordinance (LXXXV of 2002),Criminal Laws (Reforms) Ordinance (LXXXVI of 2002),etc.</DIV><hr>Whereas it is expedient to provide a general Penal Code for Pakistan:

         <P>
           It is enacted as follows:-
         </P>
         <hr>
         <div align="center">
           <h4>CHAPTER I</h4>
           <h4>INTRODUCTION</h4>
         </div>
         <table border="0">
          <?php 

          $search = $_POST['search'];

          $sql     = " select * from penal_code where Heading like '%$search%' OR Explanation like '%$search%' OR More_Explanation like '%$search%' ORDER BY Num DESC"; 
          $result  = mysqli_query($conn, $sql);
          $num     = mysqli_num_rows($result);

          if($num>0){

           for ($i=0; $i<$num ; $i++) { 

             $row = mysqli_fetch_array($result);

             echo '
             <tr>
             <td valign="top">
             <nobr><b>'.$row["Num"].'</b></nobr>
             </td><td valign="top"><b>'.$row["Heading"].'</b><br>'.$row["Explanation"].'</td>';
             
             if (strlen($row["More_Explanation"]) > 0){
                    # code...

              echo '<div class="col-md-12"><td><h4><strong>ILLUSTRATION<strong></h4></td></div><br><td>'.$row["More_Explanation"].'</td></tr>';
            }
            else{
              echo '</tr>';
            } 
            
            
          }
        }
        else{
          echo "<h1>No Result Found</h1>"; 
        }
        ?>
        
      </table>
    </section>
  </div>
</div>
</div>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</body>
</html> 
