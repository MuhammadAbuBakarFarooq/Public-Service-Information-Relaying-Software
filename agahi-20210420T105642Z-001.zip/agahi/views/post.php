<?php 
include("../action/connection.php");
session_start();
include("../partials/header.php");


?>



<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="well well-sm">
                <form class="form-horizontal" action="../action/userPost.php" method="post" enctype="multipart/form-data">
                    <fieldset>
                        <legend class="text-left">Add Post</legend>

                        <!-- heading-->
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="heading">Heading</label>
                            <div class="col-md-9">
                                <input type="text" class="form-control" id="heading" name="heading" placeholder="Enter the title" required>
                            </div>
                        </div>

                        <!-- type-->
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="type">Type</label>
                            <div class="col-md-9">
                                <select id="type" class="form-control" name="type">
                                    <option>News Alert</option>
                                    <option>Event</option>
                                    <option>Lost</option>
                                    <option>Found</option>
                                </select>
                            </div>
                        </div>
                        <!-- department -->
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="dept">Department</label>
                            <div class="col-md-9">
                                <select id="dept" class="form-control" name="dept">
                                    <option>Police</option>
                                    <option>Rescue</option>
                                    <option>Fire Brigade</option>
                                    <option>Lost&found</option>
                                    <option>Sports</option>
                                    <option>Education</option>
                                </select>
                            </div>
                        </div>

                        <!-- location -->

                        <div class="form-group">
                            <label class="col-md-3 control-label" for="loc">Location</label>
                            <div class="col-md-9">
                                <input type="text" class="form-control" id="loc" name="loc" placeholder="Enter the title" required>
                            </div>
                        </div>
                        

                        <!-- image -->
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="image">Add Image</label>
                            <div class="col-md-9">
                                <input type="file" class="form-control" id="image" name="uploadfile" value="" >
                            </div>
                        </div>

                        <!-- <div class="form-group">
                            <div class="col-md-9">
                                <label class="col-md-3 control-label lebal-style" for="image">Add image</label>
                                <input type="file" class="form-control input-style" id="image" name="uploadfile" value=""/>
                            </div>
                        </div> -->


                        <!-- Message body -->
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="message">Your message</label>
                            <div class="col-md-9">
                               <textarea class="form-control" id="message" type="text" name="message" placeholder="Please enter your message here..." rows="5" required></textarea>
                           </div>
                       </div>

                       <!-- Submission -->
                       <div class="form-group">
                        <div class="col-md-12 text-right">
                            <button type="submit" class="btn btn-primary btn-lg">Submit</button>
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>
</div>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</body>
</html>