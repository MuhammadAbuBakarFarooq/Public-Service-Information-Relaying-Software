<?php 
include("../action/connection.php");
session_start();

include("../partials/infoHeader.php");


?>




<div class="container">   
  <div class="col-md-12 product-info">
    <ul id="myTab" class="nav nav-tabs">

      <li class="active"><a href="#service-one" data-toggle="tab">Pakistan Penal Code</a></li>
      

    </ul>
    <!-- <a href="addInfo.php"><button class="btn btn-primary pull-right">Add New Penal Code</button></a> -->
    <div id="myTabContent" class="tab-content">
      <div class="tab-pane fade in active" id="service-one">

        <section class="container product-info" style="padding-top: 2%; background-color: white;">
         Links: <a href="www.pakistani.org">Constitution of Pakistan</a> | <a href="www.pakistani.org">Legislation</a> | <a href="www.pakistani.org">www.pakistani.org</a> | 

         <?php 

         if(isset($_SESSION["userName"] )){


          $new=$_SESSION['userName'];

          $queryName = "SELECT  * FROM users WHERE userName like'$new'";

          $result = mysqli_query($conn, $queryName);
          $check = mysqli_fetch_array($result);

          if (($check["type"])==0) {
                # code...
            echo'<a href="addInfo.php"><button class="btn btn-primary">Add New Penal Code</button></a><br><hr>
            ';
          }
        }
        ?>



        <H2 align="center">Pakistan Penal Code (Act XLV of 1860)</H2>
        <H3 align="center">Act XLV of 1860</H3>
        <H4 align="center">October 6th, 1860</H4>
        <DIV ALIGN="CENTER">Amended by:
        Criminal Law (Amendment) Act, 2012 (XXIII of 2002),Criminal Law (Third Amendment) Act, 2011 (XXVI of 2011),Criminal Law (Second Amendment) Act, 2011 (XXV of 2011),Criminal Law (Amendment) Act, 2011 (XX of 2011),Criminal Law (Amendment) Act, 2010 (I of 2010),Protection of Women (Criminal Laws Amendment) Act, 2006,Criminal Laws (Amendment) Act, 2004 (I of 2005),Criminal Law (Amendment) Ordinance (LXXXV of 2002),Criminal Laws (Reforms) Ordinance (LXXXVI of 2002),etc.</DIV><hr>Whereas it is expedient to provide a general Penal Code for Pakistan:

        <P>
         It is enacted as follows:-
       </P>
       <hr>
       <div align="center">
         <h4>CHAPTER I</h4>
         <h4>INTRODUCTION</h4>
       </div>
       <table border="0">
        <?php 

        $sql     = " select * from penal_code ORDER BY Num"; 
        $result  = mysqli_query($conn, $sql);
        $num     = mysqli_num_rows($result);

        if($result){

         for ($i=0; $i<$num ; $i++) { 

           $row = mysqli_fetch_array($result);

           echo '
           <tr>
           <td valign="top">
           <nobr><b>'.$row["Num"].'</b></nobr>
           </td><td valign="top"><b>'.$row["Heading"].'</b><br>'.$row["Explanation"].'</td>';

           if (strlen($row["More_Explanation"]) > 0){
                    # code...

            echo '<div class="col-md-12"><td><h4><strong>ILLUSTRATION<strong></h4></td></div><br><td>'.$row["More_Explanation"].'</td></tr>';
          }
          else{
            echo '</tr>';
          } 


        }
      }
      ?>

    </table>
  </section>
</div>
</div>
</div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</body>
</html>
</body>
</html>
