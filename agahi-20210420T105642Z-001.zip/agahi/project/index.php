  <?php 
include("action/connection.php");
session_start();
include("partials/indexHeader.php");

echo'

  <h3 style="margin-left: 6%; margin-top: 2%;">
    <a href="views/latest.php">Latest News </a>|
    <a href="views/latest.php"> View All</a>
  </h3>';
  // <!-- </div> -->
  

  $img = array();
  $heading = array();
  $type = array();
  $P_id = array();
  $date_time = array();
  $location = array();
  $dept = array();
  $userName = array();

  $sql = "select user_emergency_post.postimage, user_emergency_post.heading, user_emergency_post.type, user_emergency_post.P_id, user_emergency_post.location, user_emergency_post.date_time, user_emergency_post.dept, users.userName from user_emergency_post join users on(users.CNIC=user_emergency_post.CNIC) where user_emergency_post.verification = 1 order by user_emergency_post.date_time DESC LIMIT 16";
  $result  = mysqli_query($conn, $sql);

  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      array_push($img , $row["postimage"]);
      array_push($heading , $row["heading"]);
      array_push($type , $row["type"]);
      array_push($P_id , $row["P_id"]);
      array_push($date_time , $row["date_time"]);
      array_push($location , $row["location"]);
      array_push($dept , $row["dept"]);
      array_push($userName , $row["userName"]);
    }
  }


  ?>


  <div class='col-md-12'>
    <div class="carousel slide media-carousel" id="media">
      <div class="carousel-inner">
        <div class="item  active">
          <div class="row">
            <div class="col-md-3">
              <?php 
              echo '<a href="views/postProfile.php?id='. $P_id[0].'&&type='.$type[0].'"> ';?><span class="thumbnail" href="#"><img alt="" src="<?php echo $img[0]; ?>"></span></a>
              <h2><?php echo $heading[0];?> </h2>
              <p>added by <strong><?php echo $userName[0]; ?></strong> Directed to <strong><?php echo $dept[0]; ?></strong><p>
                <strong><?php echo $date_time[0]; ?></strong>
              </div>          

              <div class="col-md-3">
                <?php 
                echo '<a class="thumbnail" href="views/postProfile.php?id='. $P_id[1].'&&type='.$type[1].'"> ';?><img alt="" src="<?php echo $img[1]; ?>"></a>
                <h2><?php echo $heading[1]; ?></h2>
                <p>added by <strong><?php echo $userName[1]; ?></strong> Directed to <strong><?php echo $dept[1]; ?></strong><p>
                 <strong> <?php echo $date_time[1]; ?></strong>
               </div>

               <div class="col-md-3">
                <?php 
                echo '<a class="thumbnail" href="views/postProfile.php?id='. $P_id[2].'&&type='.$type[2].'"> ';?><img alt="" src="<?php echo $img[2]; ?>"></a>
                <h2><?php echo $heading[2]; ?></h2>
                <p>added by <strong><?php echo $userName[2]; ?></strong> Directed to <strong><?php echo $dept[2]; ?></strong><p>
                  <strong><?php echo $date_time[2]; ?></strong>
                </div> 
                <div class="col-md-3">
                  <?php 
                  echo '<a class="thumbnail" href="views/postProfile.php?id='. $P_id[3].'&&type='.$type[3].'"> ';?><img alt="" src="<?php echo $img[3]; ?>"></a>
                  <h2><?php echo $heading[3]; ?></h2>
                  <p>added by <strong><?php echo $userName[3]; ?></strong> Directed to <strong><?php echo $dept[3]; ?></strong><p>
                    <strong><?php echo $date_time[3]; ?></strong>
                  </div>
                </div>
              </div>
              <?php
              for($i = 4; $i < count($img) && $i+4 <= count($img); $i++){
                echo '<div class="item">
                <div class="row">
                  <div class="col-md-3">
                    <a class="thumbnail" href="views/postProfile.php?id='.$P_id[$i].'&&type='.$type[$i].'"><img alt="" src='. $img[$i].'></a>
                    <h2>'. $heading[$i].'</h2>
                    added by <strong>'.$userName[$i].'</strong><br>
                    <strong>  '. $date_time[$i].'</strong>

                  </div>          
                  <div class="col-md-3">
                    <a class="thumbnail" href="views/postProfile.php?id='.$P_id[$i+1].'&&type='.$type[$i+1].'"><img alt="" src='. $img[$i+1].'></a>
                    <h2>'. $heading[$i+1].'</h2>
                    added by <strong>'.$userName[$i].'</strong><br>
                    <strong>'. $date_time[$i+1].'</strong>

                  </div>
                  <div class="col-md-3">
                    <a class="thumbnail" href="views/postProfile.php?id='.$P_id[$i+2].'&&type='.$type[$i+2].'"><img alt="" src='. $img[$i+2].'></a>
                    <h2>'. $heading[$i+2].'</h2>
                    added by <strong>'.$userName[$i].'</strong><br>
                    <strong>'. $date_time[$i+2].'</strong>

                  </div> 
                  <div class="col-md-3">
                    <a class="thumbnail" href="views/postProfile.php?id='.$P_id[$i+3].'&&type='.$type[$i+3].'"><img alt="" src='.$img[$i+3].'></a>
                    <h2>'. $heading[$i+3].'</h2>
                    added by <strong>'.$userName[$i].'</strong><br>
                    <strong>'. $date_time[$i+3].'</strong>

                  </div>        
                </div>
              </div>';
              $i = $i+4;
            }
            ?>
            <a data-slide="prev" href="#media" class="left carousel-control"><span class="glyphicon glyphicon-chevron-left"></span></a>
            <a data-slide="next" href="#media" class="right carousel-control"><span class="glyphicon glyphicon-chevron-right"></span></a>
          </div>    
        </div>


        <h3 style="margin-left: 6%; margin-top: 2%;">
          <a href="views/viewAll.php?type=News Alert">News Alerts </a>|
          <a href="views/viewAll.php?type=News Alert"> View All</a>
        </h3>
        <!-- </div> -->
        <?php 

        $img = array();
        $heading = array();
        $type = array();
        $P_id = array();
        $date_time = array();
        $location = array();
        $dept = array();
        $userName = array();

        $sql = "select user_emergency_post.postimage, user_emergency_post.heading, user_emergency_post.type, user_emergency_post.P_id, user_emergency_post.location, user_emergency_post.date_time, user_emergency_post.dept, users.userName from user_emergency_post join users on(users.CNIC=user_emergency_post.CNIC) where user_emergency_post.verification=1 and user_emergency_post.type = 'News Alert' order by user_emergency_post.date_time DESC LIMIT 16";
        $result  = mysqli_query($conn, $sql);

        if ($result->num_rows > 0) {
    // output data of each row
          while($row = $result->fetch_assoc()) {
            array_push($img , $row["postimage"]);
            array_push($heading , $row["heading"]);
            array_push($type , $row["type"]);
            array_push($P_id , $row["P_id"]);
            array_push($date_time , $row["date_time"]);
            array_push($location , $row["location"]);
            array_push($dept , $row["dept"]);
            array_push($userName , $row["userName"]);
          }
        }


        ?>


        <div class='col-md-12'>
          <div class="carousel slide media-carousel" id="mediaN">
            <div class="carousel-inner">
              <div class="item  active">
                <div class="row">
                  <div class="col-md-3">
                   <?php 
                   echo '<a href="views/postProfile.php?id='. $P_id[0].'&&type='.$type[0].'"> ';?><span class="thumbnail" href="#"><img alt="" src="<?php echo $img[0]; ?>"></span></a>
                   <h2><?php echo $heading[0];?> </h2>
                   <p>added by <strong><?php echo $userName[0]; ?></strong> Directed to <strong><?php echo $dept[0]; ?></strong><p>
                    <strong><?php echo $date_time[0]; ?></strong>
                  </div>          

                  <div class="col-md-3">
                    <?php 
                    echo '<a class="thumbnail" href="views/postProfile.php?id='. $P_id[1].'&&type='.$type[1].'"> ';?><img alt="" src="<?php echo $img[1]; ?>"></a>
                    <h2><?php echo $heading[1]; ?></h2>
                    <p>added by <strong><?php echo $userName[1]; ?></strong> Directed to <strong><?php echo $dept[1]; ?></strong><p>
                     <strong> <?php echo $date_time[1]; ?></strong>
                   </div>

                   <div class="col-md-3">
                    <?php 
                    echo '<a class="thumbnail" href="views/postProfile.php?id='. $P_id[2].'&&type='.$type[2].'"> ';?><img alt="" src="<?php echo $img[2]; ?>"></a>
                    <h2><?php echo $heading[2]; ?></h2>
                    <p>added by <strong><?php echo $userName[2]; ?></strong> Directed to <strong><?php echo $dept[2]; ?></strong><p>
                      <strong><?php echo $date_time[2]; ?></strong>
                    </div> 
                    <div class="col-md-3">
                      <?php 
                      echo '<a class="thumbnail" href="views/postProfile.php?id='. $P_id[3].'&&type='.$type[3].'"> ';?><img alt="" src="<?php echo $img[3]; ?>"></a>
                      <h2><?php echo $heading[3]; ?></h2>
                      <p>added by <strong><?php echo $userName[3]; ?></strong> Directed to <strong><?php echo $dept[3]; ?></strong><p>
                        <strong><?php echo $date_time[3]; ?></strong>
                      </div>
                    </div>
                  </div>
                  <?php
                  for($i = 4; $i < count($img) && $i+4 <= count($img); $i++){
                    echo '<div class="item">
                    <div class="row">
                      <div class="col-md-3">
                        <a class="thumbnail" href="views/postProfile.php?id='.$P_id[$i].'&&type='.$type[$i].'"><img alt="" src='. $img[$i].'></a>
                        <h2>'. $heading[$i].'</h2>
                        added by <strong>'.$userName[$i].'</strong><br>
                        <strong>  '. $date_time[$i].'</strong>

                      </div>          
                      <div class="col-md-3">
                        <a class="thumbnail" href="views/postProfile.php?id='.$P_id[$i+1].'&&type='.$type[$i+1].'"><img alt="" src='. $img[$i+1].'></a>
                        <h2>'. $heading[$i+1].'</h2>
                        added by <strong>'.$userName[$i].'</strong><br>
                        <strong>'. $date_time[$i+1].'</strong>

                      </div>
                      <div class="col-md-3">
                        <a class="thumbnail" href="views/postProfile.php?id='.$P_id[$i+2].'&&type='.$type[$i+2].'"><img alt="" src='. $img[$i+2].'></a>
                        <h2>'. $heading[$i+2].'</h2>
                        added by <strong>'.$userName[$i].'</strong><br>
                        <strong>'. $date_time[$i+2].'</strong>

                      </div> 
                      <div class="col-md-3">
                        <a class="thumbnail" href="views/postProfile.php?id='.$P_id[$i+3].'&&type='.$type[$i+3].'"><img alt="" src='.$img[$i+3].'></a>
                        <h2>'. $heading[$i+3].'</h2>
                        added by <strong>'.$userName[$i].'</strong><br>
                        <strong>'. $date_time[$i+3].'</strong>

                      </div>        
                    </div>
                  </div>';
                  $i = $i+4;
                }
                ?>
                <a data-slide="prev" href="#mediaN" class="left carousel-control"><span class="glyphicon glyphicon-chevron-left"></span></a>
                <a data-slide="next" href="#mediaN" class="right carousel-control"><span class="glyphicon glyphicon-chevron-right"></span></a>
              </div>    
            </div>

            <h3 style="margin-left: 6%; margin-top: 2%;">
              <a href="views/viewAll.php?type=Event">Events </a>|
              <a href="views/viewAll.php?type=Event"> View All</a>
            </h3>

            <?php 

            $img = array();
            $heading = array();
            $type = array();
            $P_id = array();
            $date_time = array();
            $location = array();
            $dept = array();
            $userName = array();

            $sql = "select user_emergency_post.postimage, user_emergency_post.heading, user_emergency_post.type, user_emergency_post.P_id, user_emergency_post.location, user_emergency_post.date_time, user_emergency_post.dept, users.userName from user_emergency_post join users on(users.CNIC=user_emergency_post.CNIC) where user_emergency_post.verification=1 and user_emergency_post.type = 'event' order by user_emergency_post.date_time DESC LIMIT 16";
            $result  = mysqli_query($conn, $sql);

            if ($result->num_rows > 0) {
    // output data of each row
              while($row = $result->fetch_assoc()) {
                array_push($img , $row["postimage"]);
                array_push($heading , $row["heading"]);
                array_push($type , $row["type"]);
                array_push($P_id , $row["P_id"]);
                array_push($date_time , $row["date_time"]);
                array_push($location , $row["location"]);
                array_push($dept , $row["dept"]);
                array_push($userName , $row["userName"]);
              }
            }


            ?>


            <div class='col-md-12'>
              <div class="carousel slide media-carousel" id="mediaE">
                <div class="carousel-inner">
                  <div class="item  active">
                    <div class="row">
                      <div class="col-md-3">
                        <?php 
                        echo '<a href="views/postProfile.php?id='. $P_id[0].'&&type='.$type[0].'"> ';?><span class="thumbnail" href="#"><img alt="" src="<?php echo $img[0]; ?>"></span></a>
                        <h2><?php echo $heading[0];?> </h2>
                        <p>added by <strong><?php echo $userName[0]; ?></strong> Directed to <strong><?php echo $dept[0]; ?></strong><p>
                          <strong><?php echo $date_time[0]; ?></strong>
                        </div>          

                        <div class="col-md-3">
                          <?php 
                          echo '<a class="thumbnail" href="views/postProfile.php?id='. $P_id[1].'&&type='.$type[1].'"> ';?><img alt="" src="<?php echo $img[1]; ?>"></a>
                          <h2><?php echo $heading[1]; ?></h2>
                          <p>added by <strong><?php echo $userName[1]; ?></strong> Directed to <strong><?php echo $dept[1]; ?></strong><p>
                           <strong> <?php echo $date_time[1]; ?></strong>
                         </div>

                         <div class="col-md-3">
                          <?php 
                          echo '<a class="thumbnail" href="views/postProfile.php?id='. $P_id[2].'&&type='.$type[2].'"> ';?><img alt="" src="<?php echo $img[2]; ?>"></a>
                          <h2><?php echo $heading[2]; ?></h2>
                          <p>added by <strong><?php echo $userName[2]; ?></strong> Directed to <strong><?php echo $dept[2]; ?></strong><p>
                            <strong><?php echo $date_time[2]; ?></strong>
                          </div> 
                          <div class="col-md-3">
                            <?php 
                            echo '<a class="thumbnail" href="views/postProfile.php?id='. $P_id[3].'&&type='.$type[3].'"> ';?><img alt="" src="<?php echo $img[3]; ?>"></a>
                            <h2><?php echo $heading[3]; ?></h2>
                            <p>added by <strong><?php echo $userName[3]; ?></strong> Directed to <strong><?php echo $dept[3]; ?></strong><p>
                              <strong><?php echo $date_time[3]; ?></strong>
                            </div>
                          </div>
                        </div>
                        <?php
                        for($i = 4; $i < count($img) && $i+4 <= count($img); $i++){
                          echo '<div class="item">
                          <div class="row">
                            <div class="col-md-3">
                              <a class="thumbnail" href="views/postProfile.php?id='.$P_id[$i].'&&type='.$type[$i].'"><img alt="" src='. $img[$i].'></a>
                              <h2>'. $heading[$i].'</h2>
                              added by <strong>'.$userName[$i].'</strong><br>
                              <strong>  '. $date_time[$i].'</strong>

                            </div>          
                            <div class="col-md-3">
                              <a class="thumbnail" href="views/postProfile.php?id='.$P_id[$i+1].'&&type='.$type[$i+1].'"><img alt="" src='. $img[$i+1].'></a>
                              <h2>'. $heading[$i+1].'</h2>
                              added by <strong>'.$userName[$i].'</strong><br>
                              <strong>'. $date_time[$i+1].'</strong>

                            </div>
                            <div class="col-md-3">
                              <a class="thumbnail" href="views/postProfile.php?id='.$P_id[$i+2].'&&type='.$type[$i+2].'"><img alt="" src='. $img[$i+2].'></a>
                              <h2>'. $heading[$i+2].'</h2>
                              added by <strong>'.$userName[$i].'</strong><br>
                              <strong>'. $date_time[$i+2].'</strong>

                            </div> 
                            <div class="col-md-3">
                              <a class="thumbnail" href="views/postProfile.php?id='.$P_id[$i+3].'&&type='.$type[$i+3].'"><img alt="" src='.$img[$i+3].'></a>
                              <h2>'. $heading[$i+3].'</h2>
                              added by <strong>'.$userName[$i].'</strong><br>
                              <strong>'. $date_time[$i+3].'</strong>

                            </div>        
                          </div>
                        </div>';
                        $i = $i+4;
                      }
                      ?>
                      <a data-slide="prev" href="#mediaE" class="left carousel-control"><span class="glyphicon glyphicon-chevron-left"></span></a>
                      <a data-slide="next" href="#mediaE" class="right carousel-control"><span class="glyphicon glyphicon-chevron-right"></span></a>
                    </div>    
                  </div>

                  <h3 style="margin-left: 6%; margin-top: 2%;">
                    <a href="views/viewAll.php?type=Found">Founds </a>|
                    <a href="views/viewAll.php?type=Found"> View All</a>
                  </h3>

                  <?php 

                  $img = array();
                  $heading = array();
                  $type = array();
                  $P_id = array();
                  $date_time = array();
                  $location = array();
                  $dept = array();
                  $userName = array();

                  $sql = "select user_emergency_post.postimage, user_emergency_post.heading, user_emergency_post.type, user_emergency_post.P_id, user_emergency_post.location, user_emergency_post.date_time, user_emergency_post.dept, users.userName from user_emergency_post join users on(users.CNIC=user_emergency_post.CNIC) where user_emergency_post.verification=1 and user_emergency_post.type = 'found' order by user_emergency_post.date_time DESC LIMIT 16";
                  $result  = mysqli_query($conn, $sql);

                  if ($result->num_rows > 0) {
    // output data of each row
                    while($row = $result->fetch_assoc()) {
                      array_push($img , $row["postimage"]);
                      array_push($heading , $row["heading"]);
                      array_push($type , $row["type"]);
                      array_push($P_id , $row["P_id"]);
                      array_push($date_time , $row["date_time"]);
                      array_push($location , $row["location"]);
                      array_push($dept , $row["dept"]);
                      array_push($userName , $row["userName"]);
                    }
                  }


                  ?>


                  <div class='col-md-12'>
                    <div class="carousel slide media-carousel" id="mediaF">
                      <div class="carousel-inner">
                        <div class="item  active">
                          <div class="row">
                            <div class="col-md-3">
                              <?php 
                              echo '<a href="views/postProfile.php?id='. $P_id[0].'&&type='.$type[0].'"> ';?><span class="thumbnail" href="#"><img alt="" src="<?php echo $img[0]; ?>"></span></a>
                              <h2><?php echo $heading[0];?> </h2>
                              <p>added by <strong><?php echo $userName[0]; ?></strong> Directed to <strong><?php echo $dept[0]; ?></strong><p>
                                <strong><?php echo $date_time[0]; ?></strong>
                              </div>          

                              <div class="col-md-3">
                                <?php 
                                echo '<a class="thumbnail" href="views/postProfile.php?id='. $P_id[1].'&&type='.$type[1].'"> ';?><img alt="" src="<?php echo $img[1]; ?>"></a>
                                <h2><?php echo $heading[1]; ?></h2>
                                <p>added by <strong><?php echo $userName[1]; ?></strong> Directed to <strong><?php echo $dept[1]; ?></strong><p>
                                 <strong> <?php echo $date_time[1]; ?></strong>
                               </div>

                               <div class="col-md-3">
                                <?php 
                                echo '<a class="thumbnail" href="views/postProfile.php?id='. $P_id[2].'&&type='.$type[2].'"> ';?><img alt="" src="<?php echo $img[2]; ?>"></a>
                                <h2><?php echo $heading[2]; ?></h2>
                                <p>added by <strong><?php echo $userName[2]; ?></strong> Directed to <strong><?php echo $dept[2]; ?></strong><p>
                                  <strong><?php echo $date_time[2]; ?></strong>
                                </div> 
                                <div class="col-md-3">
                                  <?php 
                                  echo '<a class="thumbnail" href="views/postProfile.php?id='. $P_id[3].'&&type='.$type[3].'"> ';?><img alt="" src="<?php echo $img[3]; ?>"></a>
                                  <h2><?php echo $heading[3]; ?></h2>
                                  <p>added by <strong><?php echo $userName[3]; ?></strong> Directed to <strong><?php echo $dept[3]; ?></strong><p>
                                    <strong><?php echo $date_time[3]; ?></strong>
                                  </div>
                                </div>
                              </div>
                              <?php
                              for($i = 4; $i < count($img) && $i+4 <= count($img); $i++){
                                echo '<div class="item">
                                <div class="row">
                                  <div class="col-md-3">
                                    <a class="thumbnail" href="views/postProfile.php?id='.$P_id[$i].'&&type='.$type[$i].'"><img alt="" src='. $img[$i].'></a>
                                    <h2>'. $heading[$i].'</h2>
                                    added by <strong>'.$userName[$i].'</strong><br>
                                    <strong>  '. $date_time[$i].'</strong>

                                  </div>          
                                  <div class="col-md-3">
                                    <a class="thumbnail" href="views/postProfile.php?id='.$P_id[$i+1].'&&type='.$type[$i+1].'"><img alt="" src='. $img[$i+1].'></a>
                                    <h2>'. $heading[$i+1].'</h2>
                                    added by <strong>'.$userName[$i].'</strong><br>
                                    <strong>'. $date_time[$i+1].'</strong>

                                  </div>
                                  <div class="col-md-3">
                                    <a class="thumbnail" href="views/postProfile.php?id='.$P_id[$i+2].'&&type='.$type[$i+2].'"><img alt="" src='. $img[$i+2].'></a>
                                    <h2>'. $heading[$i+2].'</h2>
                                    added by <strong>'.$userName[$i].'</strong><br>
                                    <strong>'. $date_time[$i+2].'</strong>

                                  </div> 
                                  <div class="col-md-3">
                                    <a class="thumbnail" href="views/postProfile.php?id='.$P_id[$i+3].'&&type='.$type[$i+3].'"><img alt="" src='.$img[$i+3].'></a>
                                    <h2>'. $heading[$i+3].'</h2>
                                    added by <strong>'.$userName[$i].'</strong><br>
                                    <strong>'. $date_time[$i+3].'</strong>

                                  </div>        
                                </div>
                              </div>';
                              $i = $i+4;
                            }
                            ?>
                            <a data-slide="prev" href="#mediaF" class="left carousel-control"><span class="glyphicon glyphicon-chevron-left"></span></a>
                            <a data-slide="next" href="#mediaF" class="right carousel-control"><span class="glyphicon glyphicon-chevron-right"></span></a>
                          </div>    
                        </div>

                        <h3 style="margin-left: 6%; margin-top: 2%;">
                          <a href="views/viewAll.php?type=Lost">Losts </a>|
                          <a href="views/viewAll.php?type=Lost"> View All</a>
                        </h3>

                        <?php 

                        $img = array();
                        $heading = array();
                        $type = array();
                        $P_id = array();
                        $date_time = array();
                        $location = array();
                        $dept = array();
                        $userName = array();

                        $sql = "select user_emergency_post.postimage, user_emergency_post.heading, user_emergency_post.type, user_emergency_post.P_id, user_emergency_post.location, user_emergency_post.date_time, user_emergency_post.dept, users.userName from user_emergency_post join users on(users.CNIC=user_emergency_post.CNIC) where user_emergency_post.verification=1 and user_emergency_post.type = 'lost' order by user_emergency_post.date_time DESC LIMIT 16";
                        $result  = mysqli_query($conn, $sql);

                        if ($result->num_rows > 0) {
    // output data of each row
                          while($row = $result->fetch_assoc()) {
                            array_push($img , $row["postimage"]);
                            array_push($heading , $row["heading"]);
                            array_push($type , $row["type"]);
                            array_push($P_id , $row["P_id"]);
                            array_push($date_time , $row["date_time"]);
                            array_push($location , $row["location"]);
                            array_push($dept , $row["dept"]);
                            array_push($userName , $row["userName"]);
                          }
                        }


                        ?>


                        <div class='col-md-12'>
                          <div class="carousel slide media-carousel" id="mediaL">
                            <div class="carousel-inner">
                              <div class="item  active">
                                <div class="row">
                                  <div class="col-md-3">
                                    <?php 
                                    echo '<a href="views/postProfile.php?id='. $P_id[0].'&&type='.$type[0].'"> ';?><span class="thumbnail" href="#"><img alt="" src="<?php echo $img[0]; ?>"></span></a>
                                    <h2><?php echo $heading[0];?> </h2>
                                    <p>added by <strong><?php echo $userName[0]; ?></strong> Directed to <strong><?php echo $dept[0]; ?></strong><p>
                                      <strong><?php echo $date_time[0]; ?></strong>
                                    </div>          

                                    <div class="col-md-3">
                                      <?php 
                                      echo '<a class="thumbnail" href="views/postProfile.php?id='. $P_id[1].'&&type='.$type[1].'"> ';?><img alt="" src="<?php echo $img[1]; ?>"></a>
                                      <h2><?php echo $heading[1]; ?></h2>
                                      <p>added by <strong><?php echo $userName[1]; ?></strong> Directed to <strong><?php echo $dept[1]; ?></strong><p>
                                       <strong> <?php echo $date_time[1]; ?></strong>
                                     </div>

                                     <div class="col-md-3">
                                      <?php 
                                      echo '<a class="thumbnail" href="views/postProfile.php?id='. $P_id[2].'&&type='.$type[2].'"> ';?><img alt="" src="<?php echo $img[2]; ?>"></a>
                                      <h2><?php echo $heading[2]; ?></h2>
                                      <p>added by <strong><?php echo $userName[2]; ?></strong> Directed to <strong><?php echo $dept[2]; ?></strong><p>
                                        <strong><?php echo $date_time[2]; ?></strong>
                                      </div> 
                                      <div class="col-md-3">
                                        <?php 
                                        echo '<a class="thumbnail" href="views/postProfile.php?id='. $P_id[3].'&&type='.$type[3].'"> ';?><img alt="" src="<?php echo $img[3]; ?>"></a>
                                        <h2><?php echo $heading[3]; ?></h2>
                                        <p>added by <strong><?php echo $userName[3]; ?></strong> Directed to <strong><?php echo $dept[3]; ?></strong><p>
                                          <strong><?php echo $date_time[3]; ?></strong>
                                        </div>
                                      </div>
                                    </div>
                                    <?php
                                    for($i = 4; $i < count($img) && $i+4 <= count($img); $i++){
                                      echo '<div class="item">
                                      <div class="row">
                                        <div class="col-md-3">
                                          <a class="thumbnail" href="views/postProfile.php?id='.$P_id[$i].'&&type='.$type[$i].'"><img alt="" src='. $img[$i].'></a>
                                          <h2>'. $heading[$i].'</h2>
                                          added by <strong>'.$userName[$i].'</strong><br>
                                          <strong>  '. $date_time[$i].'</strong>

                                        </div>          
                                        <div class="col-md-3">
                                          <a class="thumbnail" href="views/postProfile.php?id='.$P_id[$i+1].'&&type='.$type[$i+1].'"><img alt="" src='. $img[$i+1].'></a>
                                          <h2>'. $heading[$i+1].'</h2>
                                          added by <strong>'.$userName[$i].'</strong><br>
                                          <strong>'. $date_time[$i+1].'</strong>

                                        </div>
                                        <div class="col-md-3">
                                          <a class="thumbnail" href="views/postProfile.php?id='.$P_id[$i+2].'&&type='.$type[$i+2].'"><img alt="" src='. $img[$i+2].'></a>
                                          <h2>'. $heading[$i+2].'</h2>
                                          added by <strong>'.$userName[$i].'</strong><br>
                                          <strong>'. $date_time[$i+2].'</strong>

                                        </div> 
                                        <div class="col-md-3">
                                          <a class="thumbnail" href="views/postProfile.php?id='.$P_id[$i+3].'&&type='.$type[$i+3].'"><img alt="" src='.$img[$i+3].'></a>
                                          <h2>'. $heading[$i+3].'</h2>
                                          added by <strong>'.$userName[$i].'</strong><br>
                                          <strong>'. $date_time[$i+3].'</strong>

                                        </div>        
                                      </div>
                                    </div>';
                                    $i = $i+4;
                                  }
                                  ?>
                                  <a data-slide="prev" href="#mediaL" class="left carousel-control"><span class="glyphicon glyphicon-chevron-left"></span></a>
                                  <a data-slide="next" href="#mediaL" class="right carousel-control"><span class="glyphicon glyphicon-chevron-right"></span></a>
                                </div>    
                              </div>


                              <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                              <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

                            </body>
                            </html>