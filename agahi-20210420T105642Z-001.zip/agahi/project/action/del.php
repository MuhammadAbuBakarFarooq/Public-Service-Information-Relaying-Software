<?php 

include("connection.php");

$id = $_GET["P_id"];

$del = "UPDATE `user_emergency_post` SET `verification`='4' WHERE `user_emergency_post`.`P_id` = '$id'";

	mysqli_query($conn, $del);

header("location:../index.php");



?>