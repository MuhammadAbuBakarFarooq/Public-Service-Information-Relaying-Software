<?php 


include("connection.php");


$userName = $_POST['loginUserName'];
$pass  = $_POST['loginPass'] ;




$sql = "SELECT * FROM users WHERE userName LIKE '$userName' AND password = '$pass' ";

$result = mysqli_query($conn, $sql);

if($result){



	$row = mysqli_fetch_array($result);
	
	if($row['userName'] == $userName){

		if($row['password'] == $pass){

			session_start();
			$_SESSION["userName"] = $row['userName'];

			echo '<script> alert(" loggedin successfully"); </script>';
			header("location:../index.php");

		}
		else{
			echo " invalid user Password ";
		}

	}
	else{
		echo " invalid user name ";
		echo '<script> alert(" invalid Username or Password"); </script>';
		header("refresh: 0.001 , url=../index.php");
	}


}

else
{

	echo "false query error invalid userName or password";
}

?>
