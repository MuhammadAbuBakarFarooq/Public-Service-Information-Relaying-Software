<?php 

error_reporting(0);


include("connection.php");


+$userName = $_POST['regUserName'];
$pass = $_POST['regPass'] ;
$email = $_POST['regEmail'] ;
$CNIC = $_POST['regCNIC'];
$contact = $_POST['regContact'];

date_default_timezone_set("Asia/Karachi");
$date =  date_create()->format('Y-m-d H:i:s');

$filname = $_FILES["uploadfile"]["name"];
$tempname = $_FILES["uploadfile"]["tmp_name"];

$folder = "../userImages/".$filname;

move_uploaded_file($tempname,$folder);

$found = "SELECT  * FROM users WHERE userName='$userName'";
$result = mysqli_query($conn, $found);


$foundemail = "SELECT  * FROM users WHERE email like'$email'";
$resultemail = mysqli_query($conn, $foundemail);

$foundCNIC = "SELECT  * FROM users WHERE CNIC like'$CNIC'";
$resultCNIC = mysqli_query($conn, $foundCNIC);
if ($result->num_rows > 0)
{

	echo "user already registered  try another user name...";

	echo '<script> alert(" user already registered  try another user name..."); </script>';
	header("refresh: 0.01 , url=../index.php");


} 
elseif ($resultemail->num_rows > 0) {
	echo "user already registered  try another Email...";

	echo '<script> alert(" user already registered  try another Email..."); </script>';
	header("refresh: 0.01 , url=../index.php");
}

elseif ($resultCNIC->num_rows > 0) {
	echo "user already registered  try another CNIC...";

	echo '<script> alert(" user already registered  try another CNIC..."); </script>';
	header("refresh: 0.01 , url=../index.php");
}

else {

	$folder = "userImages/".$filname;

	$sql = " INSERT INTO `publicservice`.`users` 
	( `CNIC`, `userName`,  `Ph_No`,   `email`, `password`, `image`, `type`, `date_time`) 
	VALUES 
	('$CNIC', '$userName', '$contact', '$email', '$pass', '$folder', '1', '$date')";
	$result = mysqli_query($conn, $sql);
	session_start();
	$_SESSION["userName"] = $userName;




	echo '<script> alert(" registered successfully"); </script>';
	header("location:../index.php");

}

?>