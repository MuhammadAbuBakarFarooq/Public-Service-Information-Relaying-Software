<?php 

$servername = "localhost";
$username = "root";
$password = "";
$db = "publicservice";

// Create connection
$conn = mysqli_connect($servername, $username, $password)
or die("Connection failed: " . mysqli_connect_error());

$database = mysqli_select_db($conn, $db);

?>
