<?php 

include("connection.php");
session_start();

$id = $_GET["id"];

$heading = $_POST['heading'] ;
$type = $_POST['type'] ;
$dept = $_POST['dept'] ;
$loc = $_POST['loc'] ;
$post = $_POST['message'] ;
$filname = $_FILES["uploadfile"]["name"];
$tempname = $_FILES["uploadfile"]["tmp_name"];

$folder = "../postImages/".$filname;

move_uploaded_file($tempname,$folder);

$imageSource = "postImages/".$filname;

$verify = $_SESSION["userName"];

$query="select type from users where userName like '$verify'";
$run = mysqli_query($conn, $query);
$check = mysqli_fetch_array($run);

if(($check["type"])==1){


	$edit = "UPDATE `user_emergency_post` SET `description`='$post',`postimage`='$imageSource', `heading`='$heading', `type`='$type', `dept`='$dept', `location`= '$loc', `verification`= '0' WHERE P_id='$id'";
	$result = mysqli_query($conn, $edit);
	echo $result;
	if($result){
	// echo "connected";
		header("location:../index.php");
	}
	else{
		echo "error";
	}
}
else{

	$edit = "UPDATE `user_emergency_post` SET `description`='$post',`postimage`='$imageSource', `heading`='$heading', `type`='$type', `dept`='$dept', `location`= '$loc', `verification`= '1' WHERE P_id='$id'";
	$result = mysqli_query($conn, $edit);
	echo $result;
	if($result){
	// echo "connected";
		header("location:../index.php");
	}
	else{
		echo "error";
	}
}
?>




