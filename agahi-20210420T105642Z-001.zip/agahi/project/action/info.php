<?php 

error_reporting(0);

include("connection.php");
session_start();


$heading = $_POST['heading'];
$id = $_POST["Id"];
$sub_no = $_POST["sub_no"];
$explanation = $_POST["explanation"];
$moreExplanation = $_POST["moreExplanation"];

	$sql = " INSERT INTO `publicservice`.`penal_code` 
	(`heading`, `Num`, `sub_no`, `Explanation` , `More_Explanation`) 
	VALUES 
	('$heading', '$id', '$sub_no', '$explanation', '$moreExplanation')";

	$result = mysqli_query($conn, $sql);

	if($result){


		echo '<script> alert(" post successfully"); </script>';
		header("location:../views/informationCenter.php");

	}
	else
	{

		echo "false query error";
	}


?>