<?php 

include("connection.php");

$id = $_GET["id"];

$edit = "UPDATE `user_emergency_post` SET `verification`= '2' WHERE P_id='$id'";
$result = mysqli_query($conn, $edit);
echo $result;
if($result){
	// echo "connected";
	header("location:../index.php");
}
else{
	echo "error";
}

?>