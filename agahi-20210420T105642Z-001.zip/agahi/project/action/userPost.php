<?php 

error_reporting(0);

include("connection.php");
session_start();


$heading = $_POST['heading'];
$type = $_POST['type'];
$dept = $_POST['dept'];
$loc = $_POST['loc'];
$post = $_POST['message'];

$filname = $_FILES["uploadfile"]["name"];
$tempname = $_FILES["uploadfile"]["tmp_name"];

$folder = "../postImages/".$filname;
move_uploaded_file($tempname,$folder);

// $CNIC = $_POST['CNIC'] ;
date_default_timezone_set("Asia/Karachi");
$datetime = date_create()->format('Y-m-d H:i:s');
// $date =  Date('y-m-d h:i:sa');
$new=$_SESSION['userName'];

$foundCNIC = "SELECT  * FROM users WHERE userName like'$new'";

$resultCNIC = mysqli_query($conn, $foundCNIC);


if($resultCNIC){



	$row = mysqli_fetch_array($resultCNIC);

	if($row){
		

		$cnic =$row["CNIC"];
	}


}

$folder = "postImages/".$filname;


$verify = $_SESSION["userName"];

$query="select type from users where userName like '$verify'";
$run = mysqli_query($conn, $query);
$check = mysqli_fetch_array($run);

if(($check["type"])==1){


	$sql = " INSERT INTO `publicservice`.`user_emergency_post` 
	(`description`, `date_time`, `CNIC`, `postimage` , `type` , `dept`, `location`, `heading`) 
	VALUES 
	('$post', '$datetime', '$cnic', '$folder', '$type', '$dept', '$loc', '$heading')";

	$result = mysqli_query($conn, $sql);

	if($result){


		echo '<script> alert(" post successfully"); </script>';
		header("location:../index.php");

	}
	else
	{

		echo "false query error";
	}
}
else{
	$sql = " INSERT INTO `publicservice`.`user_emergency_post` 
	(`description`, `date_time`, `CNIC`, `postimage` , `type` , `dept`, `location`, `heading`,`verification`) 
	VALUES 
	('$post', '$datetime', '$cnic', '$folder', '$type', '$dept', '$loc', '$heading', '1')";

	$result = mysqli_query($conn, $sql);

	if($result){


		echo '<script> alert(" post successfully"); </script>';
		header("location:../index.php");

	}
	else
	{

		echo "false query error";
	}
}

?>