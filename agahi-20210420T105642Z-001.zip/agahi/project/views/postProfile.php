<?php 
include("../action/connection.php");
session_start();
include("../partials/header.php");


?>



<div class="container" style="background-color: white; margin-top: 5%; /*width: 82%*/;
/*margin-left: 143px; padding-left: 6%;*/ margin-bottom: 6%;">

<div class="row">
    <?php 

    $id = $_GET["id"];
    $type = $_GET["type"];

    $sql     = " select user_emergency_post.postimage, user_emergency_post.verification,user_emergency_post.description, user_emergency_post.heading, user_emergency_post.type, user_emergency_post.P_id, user_emergency_post.location,user_emergency_post.date_time, user_emergency_post.dept, users.userName from user_emergency_post join users on(users.CNIC=user_emergency_post.CNIC) where user_emergency_post.P_id = '$id'"; 
    $result  = mysqli_query($conn, $sql);

    $row = mysqli_fetch_array($result);

    

    echo '


    <div class="col-xs-12 col-md-9">';

    if($row["postimage"] == "postImages/"){
    echo'  
      <a href="#" class="thumbnail">
            <img src="profile.jpg" style="height:500px; width:550;">
        </a>';

    }else{

          echo'
        <a href="#" class="thumbnail">
            <img src="../'.$row["postimage"].'" style="height:500px; width:550;">
        </a>';

    }echo'
        <h2>'.$row["heading"].'</h2><br>
        <p>'.$row["description"].'</p>
        <br>
        <br>
        <p>This '.$row["type"].' is added by <strong>'.$row["userName"].'</strong>
            located at <strong>'.$row["location"].'</strong> directed to <strong>'.$row["dept"].'</strong></p><br>
            <strong>'.$row["date_time"].'</strong><br><br>';

            
            if(isset($_SESSION["userName"] )){
                $new=$_SESSION['userName'];

                $query="select type from users where userName like '$new'";
                $run = mysqli_query($conn, $query);
                $check = mysqli_fetch_array($run);

                if(($check["type"])==0){

                    if(($row["verification"])==0){

                        echo'
                        <a href="../action/verification.php?id='.$row["P_id"].'" class="btn btn-primary">Verify</a>
                        <a href="../action/rejection.php?id='.$row["P_id"].'" class="btn btn-danger">Reject</a>';

                    }

                }
            }
            $sqlQuery = "select users.userName, user_emergency_post.P_id from users join user_emergency_post on(users.CNIC=user_emergency_post.CNIC) where P_id = '$id'";
            $runQuery = mysqli_query($conn, $sqlQuery);
            $checkQuery = mysqli_fetch_array($runQuery);

            if(isset($_SESSION["userName"] )){
             $new=$_SESSION['userName'];
             if($new==$checkQuery["userName"]){
                echo '

                <a href="edit.php?P_id='.$checkQuery['P_id'].'" class="btn btn-primary">Edit</a>
                <a href="../action/del.php?P_id='.$checkQuery['P_id'].'" class="btn btn-danger">Delete</a>


                ';
            }
        }

        echo "</div><h3>Related News </strong></h3>";
        $sql     = " select users.userName, users.image, user_emergency_post.P_id,user_emergency_post.type, user_emergency_post.description,user_emergency_post.heading, user_emergency_post.postimage, user_emergency_post.date_time from users join user_emergency_post on(users.CNIC=user_emergency_post.CNIC) where user_emergency_post.verification=1 and user_emergency_post.type like '$type' and user_emergency_post.P_id!=$id ORDER BY date_time DESC"; 
        $result  = mysqli_query($conn, $sql);
        $num     = mysqli_num_rows($result);

        if($result){

           for ($i=0; $i<$num ; $i++) { 

             $row = mysqli_fetch_array($result);

             echo ' <div class="col-xs-12 col-md-3">
             <a href="postProfile.php?id='.$row["P_id"].'&&type='.$row["type"].'" class="thumbnail">
              <img src="../'.$row["postimage"].'" style="height:200px; width:300px;">
              <h4>'.$row["heading"].'</h4>

          </a>
      </div>
      ';}}



      ?>

  </div>
  </div>


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</body>
</html>