<!DOCTYPE html>
<html >
<head>
  <link rel="icon"  href="images/final-logo.png">
  <title>Agahi</title>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=courier+new" rel="stylesheet">
  <link href="https://fortawesome.github.io/Font-Awesome/assets/font-awesome/css/font-awesome.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="stylesheet" type="text/css" href="css/index.css">
  <!-- <link rel="stylesheet" type="text/css" href="css/lost&found.css"> -->


</head>
<body>

  <div class="header hidden-xs container-fluid">  

    <div class="row head">   
      <div class="logo"> 
        <a href="index.php" class="col-md-1"><img src="images/final-logo.png"></a> 

        <h1 class="col-md-3 agahi"> <strong >AGAHI</strong> </h1>
        <h1 class="col-md-6"> <strong"> Public Information Relaying Center </strong"> 

          <form class="navbar-form navbar-right" role="search" method="post" action="views/search.php">
            <div class="form-group">
              <input type="text" class="form-control searchInput" name="search" placeholder="Search">
              <button type="submit" class="form-control btn-default navSearch">
                <span class="glyphicon glyphicon-search" aria-hidden="true"></span>
              </button>
            </div>
          </form>
          <span style="font-size: 20px;"><br>Awareness is greatest agent for change</span></h1>
          <!-- <h1 class="col-md-4"> <strong> <i>   Awareness is Greatest Agent for Change </i></strong> </h1> -->

        </div>
      </div>
    </div>

    <!-- navbar  -->
    <nav class="navbar navbar-inverse"  role="navigation" >

      <div class="container navbar-width"> 
        <div class="navbar-header hidden-lg hidden-sm hidden-md"><span>  <a href="index.php"> <img src="images/final-logo.png" style="height: 50px; width: 50px;"></a></span>
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>

        </div>
        <div id="navbar" class="navbar-collapse collapse">



          <ul class="nav navbar-nav">
            <li><a   href="index.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a></li>

            <li><a href="views/viewAll.php?type=News Alert"> News Alerts </a></li>
            <li><a href="views/viewAll.php?type=Event"> Events </a></li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" > 
                Lost&Found <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="views/viewAll.php?type=Lost"><strong>Losts</strong></a></li>
                  <li><a href="views/viewAll.php?type=Found"><strong>Founds</strong></a></li>


                </ul>
              </li>



              <li><a href="views/informationCenter.php"></i> Information Center</a></li>




            </ul>
            <ul class="nav navbar-nav navbar-right">
             <?php 



             if(isset($_SESSION["userName"] )){


              $new=$_SESSION['userName'];

              $img = "SELECT  * FROM users WHERE userName like'$new'";

              $query = mysqli_query($conn, $img);
              $check = mysqli_fetch_array($query);

              echo '   <li class="dropdown text" style="margin-top: -12px;">                               

              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" > 
                <img src="'.$check["image"].'" style="height: 50px; width: 50px; border-radius: 50%;"> '. $_SESSION["userName"] .'<span class="caret"></span></a>
                <ul class="dropdown-menu">

                <li><a href="views/userProfile.php"><strong>Profile</strong></a></li>
                  <li><a href="#"><strong>Setting</strong></a></li>
                  <li><a href="#"><strong>Help Center</strong></a></li>
                  <li><a href="logout.php" ><strong> Logout</strong></a></li>

                </ul>






              </li>

              <li>    
                <a href="views/post.php"><span class="glyphicon glyphicon-arrow-right" aria-hidden="true"></span> Post </a>
              </li>';

            }
            else{

              echo   ' <li>                               
              <a href="#" data-toggle="modal" data-target="#loginModal"><span class="glyphicon glyphicon-user" aria-hidden="true" ></span> 
                Login </a>
              </li>';


            }

            if(isset($_SESSION["userName"] )){
              echo ' 

              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" ><span class="glyphicon glyphicon-bell" aria-hidden="true"></span> </a>
                <ul class="dropdown-menu pre-scrollable notification">
                  ';

                  $name=$_SESSION['userName'];

                  $sql     = " select users.userName, user_emergency_post.P_id,user_emergency_post.type, user_emergency_post.heading, user_emergency_post.date_time from users join user_emergency_post on(users.CNIC=user_emergency_post.CNIC) where user_emergency_post.verification=1 and users.userName NOT like '$name' ORDER BY date_time DESC"; 
                  $result  = mysqli_query($conn, $sql);
                  $num     = mysqli_num_rows($result);

                  if($result){

                   for ($i=0; $i<$num ; $i++) { 

                     $row = mysqli_fetch_array($result);

                     echo '





                     <li><a href="views/postProfile.php?id='.$row["P_id"].'&&type='.$row["type"].'">
                       <strong class="text" style="color:#2e944a;">'.$row["userName"].'</strong> added a new post
                       <br>
                       <strong>'.$row["heading"].'</strong>


                     </a></li><hr>
                     ';
                   }



                 }
               }

               echo'

             </ul>
           </li>';



           if(isset($_SESSION["userName"] )){


            echo ' 

            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" ><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span> </a>
              <ul class="dropdown-menu pre-scrollable notification">
                ';


                $new=$_SESSION['userName'];

                $query="select type from users where userName like '$new'";
                $run = mysqli_query($conn, $query);
                $check = mysqli_fetch_array($run);

                if(($check["type"])==0){

                  $sql     = " select users.userName, user_emergency_post.P_id,user_emergency_post.type, user_emergency_post.heading, user_emergency_post.date_time from users join user_emergency_post on(users.CNIC=user_emergency_post.CNIC) where user_emergency_post.verification=0 ORDER BY date_time DESC"; 
                  $result  = mysqli_query($conn, $sql);
                  $num     = mysqli_num_rows($result);

                  if($num>0){

                    for ($i=0; $i<$num ; $i++) { 

                     $row = mysqli_fetch_array($result);


                     echo '

                     <li><a href="views/postProfile.php?id='.$row["P_id"].'&&type='.$row["type"].'">
                       <strong class="text">'.$row["userName"].'</strong> add a new post
                       <br>
                       '.$row["heading"].'


                     </a></li><hr>
                     ';
                   }



                 }
                 else{
                  echo "<h4>No Pending Post</h4>";
                 }

               }

               elseif(($check["type"])==1){

                $new=$_SESSION['userName'];

                $sql     = " select users.userName, user_emergency_post.P_id,user_emergency_post.type, user_emergency_post.heading, user_emergency_post.verification, user_emergency_post.date_time from users join user_emergency_post on(users.CNIC=user_emergency_post.CNIC) where users.userName like '$new' ORDER BY date_time DESC"; 
                $result  = mysqli_query($conn, $sql);
                $num     = mysqli_num_rows($result);

                if($result){

                  for ($i=0; $i<$num ; $i++) { 

                   $row = mysqli_fetch_array($result);

                   if(($row["verification"])==1){

                     echo '

                     <li><a href="views/postProfile.php?id='.$row["P_id"].'&&type='.$row["type"].'">
                       <strong class="text">Your Post is <span style = "color:#2e944a;">Verified</span></strong>
                       <br>
                       <strong>'.$row["heading"].'</strong>


                     </a></li><hr>
                     ';
                   }

                   elseif(($row["verification"])==0) {
                     echo '

                     <li><a href="views/postProfile.php?id='.$row["P_id"].'&&type='.$row["type"].'">
                       <strong class="text">Your Post is <span style = "color:#3b5998;">Pending</span></strong>
                       <br>
                       <strong>'.$row["heading"].'</strong>


                     </a></li><hr>
                     ';
                   }

                   elseif(($row["verification"])==2) {

                    echo '

                    <li><a href="views/postProfile.php?id='.$row["P_id"].'&&type='.$row["type"].'">
                      <strong class="text">Your Post is <span style = "color:red;">Rejected</span></strong>
                      <br>
                      <strong>'.$row["heading"].'</strong>


                    </a></li><hr>
                    ';

                  }

                }



              }
            }
            elseif (($check["type"])==2) {
              $sql     = " select users.userName, user_emergency_post.P_id,user_emergency_post.type, user_emergency_post.heading, user_emergency_post.date_time from users join user_emergency_post on(users.CNIC=user_emergency_post.CNIC) where user_emergency_post.dept like 'Rescue' and users.userName NOT LIKE '$new' ORDER BY date_time DESC"; 
              $result  = mysqli_query($conn, $sql);
              $num     = mysqli_num_rows($result);

              if($result){

                for ($i=0; $i<$num ; $i++) { 

                 $row = mysqli_fetch_array($result);

                 echo '

                 <li><a href="views/postProfile.php?id='.$row["P_id"].'&&type='.$row["type"].'">
                   <strong class="text">'.$row["userName"].'</strong> add a new post
                   <br>
                   '.$row["heading"].'


                 </a></li><hr>
                 ';
               }



             }
           }
           if (($check["type"])==3) {
            $sql     = " select users.userName, user_emergency_post.P_id,user_emergency_post.type, user_emergency_post.heading, user_emergency_post.date_time from users join user_emergency_post on(users.CNIC=user_emergency_post.CNIC) where user_emergency_post.dept like 'Police' and users.userName NOT LIKE '$new' ORDER BY date_time DESC"; 
            $result  = mysqli_query($conn, $sql);
            $num     = mysqli_num_rows($result);

            if($result){

              for ($i=0; $i<$num ; $i++) { 

               $row = mysqli_fetch_array($result);

               echo '

               <li><a href="views/postProfile.php?id='.$row["P_id"].'&&type='.$row["type"].'">
                 <strong class="text">'.$row["userName"].'</strong> add a new post
                 <br>
                 '.$row["heading"].'


               </a></li><hr>
               ';
             }



           }
         }
         if (($check["type"])==4) {
          $sql     = " select users.userName, user_emergency_post.P_id,user_emergency_post.type, user_emergency_post.heading, user_emergency_post.date_time from users join user_emergency_post on(users.CNIC=user_emergency_post.CNIC) where user_emergency_post.dept like 'Lost&found' and users.userName NOT LIKE '$new' ORDER BY date_time DESC"; 
          $result  = mysqli_query($conn, $sql);
          $num     = mysqli_num_rows($result);

          if($result){

            for ($i=0; $i<$num ; $i++) { 

             $row = mysqli_fetch_array($result);

             echo '

             <li><a href="views/postProfile.php?id='.$row["P_id"].'&&type='.$row["type"].'">
               <strong class="text">'.$row["userName"].'</strong> add a new post
               <br>
               '.$row["heading"].'


             </a></li><hr>
             ';
           }



         }
       }
     }

     ?>


   </ul>
 </li>


</ul>

</div>
</div>
</nav>








<div id="loginModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content text-primary">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Login</h4>
      </div>
      <div class="modal-body">
        <form action="action/login.php" method="post"">
          <div class="form-group">
            <label for="loginUserName">User Name:</label>
            <input type="text" class="form-control" id="loginUserName" name="loginUserName">
          </div>
          <div class="form-group">
            <label for="loginPass">Password:</label>
            <input type="password" class="form-control" id="loginPass" name="loginPass">
          </div>
          <div class="checkbox">
            <label><input type="checkbox" name="loginRemember"> Remember me</label>
          </div>
          <button type="submit" class="btn btn-default">Log In</button> or

          <a href="#" data-toggle="modal" data-target="#regModal" data-dismiss="modal"> Register</a>

        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>


<div id="regModal" class="modal fade " role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content text-primary">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Register</h4>
      </div>
      <div class="modal-body">
        <form action="action/reg.php" method="POST" enctype="multipart/form-data">
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="userName">User Name</label>
              <input type="text" class="form-control" id="userName" name="regUserName" placeholder="User Name" required>
            </div>
            <div class="form-group col-md-6">
              <label for="regPass">Password</label>
              <input type="password" class="form-control" id="regPass" name="regPass" placeholder="Password" required>
            </div>
          </div>

          <div class="form-row">

            <div class="form-group col-md-6">
              <label for="regEmail">Email</label>
              <input type="email" class="form-control" id="regEmail" name="regEmail" placeholder="Email" required>
            </div>
            <div class="form-group col-md-6">
              <label for="CNIC">CNIC</label>
              <input type="numeric" class="form-control" id="CNIC" name="regCNIC" placeholder="CNIC" required>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="Contact">Contact</label>
              <input type="numeric" class="form-control" id="Contact" name="regContact" placeholder="+923041234567" required>
            </div>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="image">Add Image</label>
                <input type="file" class="form-control" id="image" name="uploadfile" value=""/ required>

              </div>
            </div>
          </div>




          <div class="form-group">
            <div class="form-check">
              <input class="form-check-input" type="checkbox" id="regAgree" required>
              <label class="form-check-label" for="regAgree">
                I agree to the <a href="#">Privacy Policy</a>
              </label>
            </div>
            <button type="submit" class="btn btn-primary">Register</button>
          </div>

        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

  <!-- <div class="col-xs-12-md-12">
    <marquee style="background-color: lightgray; color: black;  font-family: helvatica; font-size: 20px; margin-bottom: 1%; width: 100%">


      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
      tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
      quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo


    </marquee>
  </div>  -->


 <!--  <nav class="navbar navbar-default" >
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand"  href="#">
          Latest News
        </a> 
        <a class="navbar-brand"  href="views/latest.php">
          View All
        </a>
      </div>
    </div>
  </nav> -->